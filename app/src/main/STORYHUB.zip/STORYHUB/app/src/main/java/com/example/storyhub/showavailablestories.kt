package com.example.storyhub

import android.os.Bundle
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.navigation.NavigationView


class showavailablestories : AppCompatActivity() {
    private val dl: DrawerLayout? = null
    private val t: ActionBarDrawerToggle? = null
    private val nv: NavigationView? = null

    lateinit var storyadapter:availabelstoriesadapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.showavailablestories)
        iniRrecycleview()
        adddataset()


    }

    private  fun adddataset(){
        var data= availablestoriesdatasource.createDataSet()
        storyadapter.submitlist(data)
    }
    private fun iniRrecycleview(){
var recyclerviewname= findViewById<RecyclerView>(R.id.recycler_view)
    recyclerviewname.layoutManager=LinearLayoutManager(this@showavailablestories)
    storyadapter=availabelstoriesadapter()
        val topspacingdecoration= availablestoriestoppadding(5)
        recyclerviewname.addItemDecoration(topspacingdecoration)
    recyclerviewname.adapter=storyadapter
    }

}