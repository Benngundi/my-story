package com.example.storyhub

class availablestoriesmodelclass (var image:Int, var name:String, var time:String, var message:String)
{

}