package com.example.storyhub

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
//import com.google.firebase.database.*
//import kotlinx.android.synthetic.main.activity_registeractivity.*


class Registeractivity : AppCompatActivity() {
    lateinit var txtusername:TextView
    lateinit var  txtuseremail:TextView
    lateinit var userpassword: TextView
    lateinit var btnsave:Button
    //lateinit var ref:DatabaseReference
    lateinit var listview:ListView
   // lateinit var userlist:MutableList<registeruser>
    override fun onCreate(savedInstanceState: Bundle?) {
       super.onCreate(savedInstanceState)
       setContentView(R.layout.activity_registeractivity)
       //  ref = FirebaseDatabase.getInstance().getReference("user")
       txtusername = findViewById(R.id.inputusername)
       txtuseremail = findViewById(R.id.useremail)
       userpassword = findViewById(R.id.inputpassword)
       btnsave = findViewById(R.id.btnregister)
       //userlist= mutableListOf()
       listview = findViewById(R.id.listviewuser)


       // link to new activities
       val txtvhaveaccount = findViewById<TextView>(R.id.txtvhaveaccount)
       val btnregister = findViewById<TextView>(R.id.btnregister)
       txtvhaveaccount.setOnClickListener {
           intent = Intent(this, loginactivity::class.java)
           startActivity(intent)
       }


       //credentials check

   }



}