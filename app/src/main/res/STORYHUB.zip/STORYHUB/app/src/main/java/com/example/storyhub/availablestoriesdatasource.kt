package com.example.storyhub

class availablestoriesdatasource {
    companion object{
        fun createDataSet(): ArrayList<availablestoriesmodelclass>{
            val list = ArrayList<availablestoriesmodelclass>()
            list.add(
                availablestoriesmodelclass(
                    R.drawable.street,
                    "The Encounter",
                    "12:01 am",
                    "Sunday, April 2, 2020. The second week after announcement of first case of the virus in my country ,Kenya." +
                            " Complete divagency of any know nomacy was the state. Schools, clubs places of worship,socia" +
                            " The perdemic had raveged the world. Complete divagency of any known nomacy.Schools, places" +
                            " The perdemic had raveged the worldthe first sunday after closure of churches by the government. " +
                            "The perdemic had raveged the worldthe first sunday after closure of churches by the government." +
                            " The perdemic had raveged the worldthe first sunday after closure of churches by the government. " +
                            "The perdemic had raveged the worldthe first sunday after closure of churches by the government." +
                            " The perdemic had raveged the worldthe first sunday after closure of churches by the government." +
                            " The perdemic had raveged the worldthe first sunday after closure of churches by the government. " +
                            "The perdemic had raveged the worldthe first sunday after closure of churches by the government. " +
                            "The perdemic had raveged the world"
                )
            )
            list.add(
                availablestoriesmodelclass(
                    R.drawable.personal,
                    "The session",
                    "12 Days ago",
                    "Why did you allow this to happen? are us still in controll? are you still up there? I knew it was time" +
                            " to site down and listen carefullu, yes am still in controll" +
                            "I knew it was time to site down and listen carefully, yes am still in controll" +
                            "He fell in love with a woman who seemed to be the epitome of the other side, and he broke the oath. On the other hand, Kabonyi and Kamau's jealousy of Waiyaki motivated the former's public tirades and the latter's spying, not their commitment to the tribe. Joshua's hardheadedness and anger precluded him from working with Waiyaki. The people do not want to be open-minded or autonomous: they just want someone to tell them what to do or think. Waiyaki is thus a tragic figure due to his own shortcomings and due to those of the people that surround him."

                )
            )
            list.add(
                availablestoriesmodelclass(
                    R.drawable.street,
                    "How it happened",
                    "11:37",
                    "Why did you allow this to happen? are us still in controll? are you still up there? I knew it was time" +
                            " to site down and listen carefullu, yes am still in controll" +
                            "I knew it was time to site down and listen carefully, yes am still in controll" +
                            "He fell in love with a woman who seemed to be the epitome of the other side, and he broke the oath. On the other hand, Kabonyi and Kamau's jealousy of Waiyaki motivated the former's public tirades and the latter's spying, not their commitment to the tribe. Joshua's hardheadedness and anger precluded him from working with Waiyaki. The people do not want to be open-minded or autonomous: they just want someone to tell them what to do or think. Waiyaki is thus a tragic figure due to his own shortcomings and due to those of the people that surround him."

                )
            )
            list.add(
                availablestoriesmodelclass(
                    R.drawable.maps,
                    "Out of the skys",
                    "11:37",
                    "Why did you allow this to happen? are us still in controll? are you still up there? I knew it was time" +
                            " to site down and listen carefullu, yes am still in controll" +
                            "I knew it was time to site down and listen carefully, yes am still in controll" +
                            "He fell in love with a woman who seemed to be the epitome of the other side, and he broke the oath. On the other hand, Kabonyi and Kamau's jealousy of Waiyaki motivated the former's public tirades and the latter's spying, not their commitment to the tribe. Joshua's hardheadedness and anger precluded him from working with Waiyaki. The people do not want to be open-minded or autonomous: they just want someone to tell them what to do or think. Waiyaki is thus a tragic figure due to his own shortcomings and due to those of the people that surround him."

                )
            )
            list.add(
                availablestoriesmodelclass(
                    R.drawable.design,
                    "Until it done",
                    "11:37",
                    "Why did you allow this to happen? are us still in controll? are you still up there? I knew it was time" +
                            " to site down and listen carefullu, yes am still in controll" +
                            "I knew it was time to site down and listen carefully, yes am still in controll" +
                            "He fell in love with a woman who seemed to be the epitome of the other side, and he broke the oath. On the other hand, Kabonyi and Kamau's jealousy of Waiyaki motivated the former's public tirades and the latter's spying, not their commitment to the tribe. Joshua's hardheadedness and anger precluded him from working with Waiyaki. The people do not want to be open-minded or autonomous: they just want someone to tell them what to do or think. Waiyaki is thus a tragic figure due to his own shortcomings and due to those of the people that surround him."

                )
            )
            list.add(
                availablestoriesmodelclass(
                    R.drawable.history,
                    "Encounter with Him",
                    "1day Ago",
                    "Sunday, April 2, 2020. The second week after announcement of first case of the virus in my country ,Kenya." +
                            " Complete divagency of any know nomacy was the state. Schools, clubs places of worship,socia" +
                            " The perdemic had raveged the world. Complete divagency of any known nomacy.Schools, places" +
                            " The perdemic had raveged the worldthe first sunday after closure of churches by the government. " +
                            "The perdemic had raveged the worldthe first sunday after closure of churches by the government." +
                            " The perdemic had raveged the worldthe first sunday after closure of churches by the government. " +
                            "The perdemic had raveged the worldthe first sunday after closure of churches by the government." +
                            " The perdemic had raveged the worldthe first sunday after closure of churches by the government." +
                            " The perdemic had raveged the worldthe first sunday after closure of churches by the government. " +
                            "The perdemic had raveged the worldthe first sunday after closure of churches by the government. " +
                            "The perdemic had raveged the world"
                )
            )
            list.add(
                availablestoriesmodelclass(
                    R.drawable.construction,
                    "The session",
                    "12 Days ago",
                    "Why did you allow this to happen? are us still in controll? are you still up there? I knew it was time" +
                            " to site down and listen carefullu, yes am still in controll" +
                            "I knew it was time to site down and listen carefullu, yes am still in controllI " +
                            "He fell in love with a woman who seemed to be the epitome of the other side, and he broke the oath. On the other hand, Kabonyi and Kamau's jealousy of Waiyaki motivated the former's public tirades and the latter's spying, not their commitment to the tribe. Joshua's hardheadedness and anger precluded him from working with Waiyaki. The people do not want to be open-minded or autonomous: they just want someone to tell them what to do or think. Waiyaki is thus a tragic figure due to his own shortcomings and due to those of the people that surround him."
                )
            )
            list.add(
                availablestoriesmodelclass(
                    R.drawable.dedication,
                    "How it happened",
                    "11:37",
                    "Why did you allow this to happen? are us still in controll? are you still up there? I knew it was time" +
                            " to site down and listen carefullu, yes am still in controll" +
                            "I knew it was time to site down and listen carefully, yes am still in controll" +
                            "He fell in love with a woman who seemed to be the epitome of the other side, and he broke the oath. On the other hand, Kabonyi and Kamau's jealousy of Waiyaki motivated the former's public tirades and the latter's spying, not their commitment to the tribe. Joshua's hardheadedness and anger precluded him from working with Waiyaki. The people do not want to be open-minded or autonomous: they just want someone to tell them what to do or think. Waiyaki is thus a tragic figure due to his own shortcomings and due to those of the people that surround him."

                )
            )
            list.add(
                availablestoriesmodelclass(
                    R.drawable.hack,
                    "Out of the skys",
                    "11:37",
                    "Why did you allow this to happen? are us still in controll? are you still up there? I knew it was time" +
                            " to site down and listen carefullu, yes am still in controll" +
                            "I knew it was time to site down and listen carefully, yes am still in controll" +
                            "He fell in love with a woman who seemed to be the epitome of the other side, and he broke the oath. On the other hand, Kabonyi and Kamau's jealousy of Waiyaki motivated the former's public tirades and the latter's spying, not their commitment to the tribe. Joshua's hardheadedness and anger precluded him from working with Waiyaki. The people do not want to be open-minded or autonomous: they just want someone to tell them what to do or think. Waiyaki is thus a tragic figure due to his own shortcomings and due to those of the people that surround him."

                )
            )
            list.add(
                availablestoriesmodelclass(
                    R.drawable.advertisment,
                    "Until it done",
                    "11:37",
                    "Good Morning, i pray you are well in the lord. may the lord give you victory in this"
                )
            )

            list.add(
                availablestoriesmodelclass(
                    R.drawable.morning,
                    "Encounter with Him",
                    "1day Ago",
                    "Sunday, April 2, 2020. The second week after announcement of first case of the virus in my country ,Kenya." +
                            " Complete divagency of any know nomacy was the state. Schools, clubs places of worship,socia" +
                            " The perdemic had raveged the world. Complete divagency of any known nomacy.Schools, places" +
                            " The perdemic had raveged the worldthe first sunday after closure of churches by the government. " +
                            "The perdemic had raveged the worldthe first sunday after closure of churches by the government." +
                            " The perdemic had raveged the worldthe first sunday after closure of churches by the government. " +
                            "The perdemic had raveged the worldthe first sunday after closure of churches by the government." +
                            " The perdemic had raveged the worldthe first sunday after closure of churches by the government." +
                            " The perdemic had raveged the worldthe first sunday after closure of churches by the government. " +
                            "The perdemic had raveged the worldthe first sunday after closure of churches by the government. " +
                            "The perdemic had raveged the world"
                )
            )
            list.add(
                availablestoriesmodelclass(
                    R.drawable.personal,
                    "The session",
                    "12 Days ago",
                    "Why did you allow this to happen? are us still in controll? are you still up there? I knew it was time" +
                            " to site down and listen carefullu, yes am still in controll" +
                            "I knew it was time to site down and listen carefullu, yes am still in controllI " +
                            "He fell in love with a woman who seemed to be the epitome of the other side, and he broke the oath. On the other hand, Kabonyi and Kamau's jealousy of Waiyaki motivated the former's public tirades and the latter's spying, not their commitment to the tribe. Joshua's hardheadedness and anger precluded him from working with Waiyaki. The people do not want to be open-minded or autonomous: they just want someone to tell them what to do or think. Waiyaki is thus a tragic figure due to his own shortcomings and due to those of the people that surround him."
                )
            )
            list.add(
                availablestoriesmodelclass(
                    R.drawable.design,
                    "How it happened",
                    "11:37",
                    "Good Morning, i pray you are well in the lord. may the lord give you victory in this"
                )
            )
            list.add(
                availablestoriesmodelclass(
                    R.drawable.maps,
                    "Out of the skys",
                    "11:37",
                    "Why did you allow this to happen? are us still in controll? are you still up there? I knew it was time" +
                            " to site down and listen carefullu, yes am still in controll" +
                            "I knew it was time to site down and listen carefully, yes am still in controll" +
                            "He fell in love with a woman who seemed to be the epitome of the other side, and he broke the oath. On the other hand, Kabonyi and Kamau's jealousy of Waiyaki motivated the former's public tirades and the latter's spying, not their commitment to the tribe. Joshua's hardheadedness and anger precluded him from working with Waiyaki. The people do not want to be open-minded or autonomous: they just want someone to tell them what to do or think. Waiyaki is thus a tragic figure due to his own shortcomings and due to those of the people that surround him."

                )
            )
            list.add(
                availablestoriesmodelclass(
                    R.drawable.history,
                    "Until it done",
                    "11:37",
                    "Good Morning, i pray you are well in the lord. may the lord give you victory in this"
                )
            )

            list.add(
                availablestoriesmodelclass(
                    R.drawable.street,
                    "Encounter with Him",
                    "1day Ago",
                    "Sunday, April 2, 2020. The second week after announcement of first case of the virus in my country ,Kenya." +
                            " Complete divagency of any know nomacy was the state. Schools, clubs places of worship,socia" +
                            " The perdemic had raveged the world. Complete divagency of any known nomacy.Schools, places" +
                            " The perdemic had raveged the worldthe first sunday after closure of churches by the government. " +
                            "The perdemic had raveged the worldthe first sunday after closure of churches by the government." +
                            " The perdemic had raveged the worldthe first sunday after closure of churches by the government. " +
                            "The perdemic had raveged the worldthe first sunday after closure of churches by the government." +
                            " The perdemic had raveged the worldthe first sunday after closure of churches by the government." +
                            " The perdemic had raveged the worldthe first sunday after closure of churches by the government. " +
                            "The perdemic had raveged the worldthe first sunday after closure of churches by the government. " +
                            "The perdemic had raveged the world"
                )
            )
            list.add(
                availablestoriesmodelclass(
                    R.drawable.personal,
                    "The session",
                    "12 Days ago",
                    "Why did you allow this to happen? are us still in controll? are you still up there? I knew it was time" +
                            " to site down and listen carefullu, yes am still in controll" +
                            "I knew it was time to site down and listen carefullu, yes am still in controllI " +
                            "He fell in love with a woman who seemed to be the epitome of the other side, and he broke the oath. On the other hand, he motivated the former's public tirades and the latter's spying, not their commitment to the tribe. Joshua's hardheadedness and anger precluded him from working with the guy. The people do not want to be open-minded or autonomous: they just want someone to tell them what to do or think. He is thus a tragic figure due to his own shortcomings and due to those of the people that surround him."

                )
            )
            list.add(
                availablestoriesmodelclass(
                    R.drawable.design,
                    "How it happened",
                    "11:37",
                    "He fell in love with a woman who seemed to be the epitome of the other side," +
                            " and he broke the oath. On the other hand, he motivated the former's public tirades and the latter's spying, not their commitment to the tribe. Joshua's hardheadedness and anger precluded him from working with the guy. The people do not want to be open-minded or autonomous: they just want someone to tell them what to do or think. He is thus a tragic figure due to his own shortcomings and due to those of the people that surround him."
+"He fell in love with a woman who seemed to be the epitome of the other side, and he broke the oath. On the other hand, he motivated the former's public tirades and the latter's spying, not their commitment to the tribe. Joshua's hardheadedness and anger precluded him from working with the guy. The people do not want to be open-minded or autonomous: they just want someone to tell them what to do or think. He is thus a tragic figure due to his own shortcomings and due to those of the people that surround him."
+"He fell in love with a woman who seemed to be the epitome of the other side, and he broke the oath. On the other hand, he motivated the former's public tirades and the latter's spying, not their commitment to the tribe. Joshua's hardheadedness and anger precluded him from working with the guy. The people do not want to be open-minded or autonomous: they just want someone to tell them what to do or think. He is thus a tragic figure due to his own shortcomings and due to those of the people that surround him."

                )
            )
            list.add(
                availablestoriesmodelclass(
                    R.drawable.maps,
                    "Out of the skys",
                    "11:37",
                    "He fell in love with a woman who seemed to be the epitome of the other side, and he broke the oath. On the other hand, he motivated the former's public tirades and the latter's spying, not their commitment to the tribe. Joshua's hardheadedness and anger precluded him from working with the guy. The people do not want to be open-minded or autonomous: they just want someone to tell them what to do or think. He is thus a tragic figure due to his own shortcomings and due to those of the people that surround him."

                )
            )
            list.add(
                availablestoriesmodelclass(
                    R.drawable.`social`,
                    "Until it done",
                    "11:37",
                    "He fell in love with a woman who seemed to be the epitome of the other side, and he broke the oath. On the other hand, he motivated the former's public tirades and the latter's spying, not their commitment to the tribe. Joshua's hardheadedness and anger precluded him from working with the guy. The people do not want to be open-minded or autonomous: they just want someone to tell them what to do or think. He is thus a tragic figure due to his own shortcomings and due to those of the people that surround him."

                )
            )


            return list
        }
    }
}